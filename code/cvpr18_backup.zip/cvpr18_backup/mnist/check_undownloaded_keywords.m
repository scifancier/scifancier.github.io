function check_undownloaded_keywords(instr,outstr,foldername)
% load filenames
if nargin == 0
    instr = 'data/keyword_6.txt';
    outstr = 'data/newkeyword_6.txt';
    foldername = 'keyword6/';
end
filenames = importdata(instr);

idx = [];
imagenum = zeros(length(filenames),1);
for i = 1:length(filenames)
    [strnum, strname] = strsplit(filenames{i},'   ');
    folder = [foldername strnum]
    L = list_files(folder);
    imagenum(i) = length(L)-1;
    if imagenum < 10
        idx = [idx,i];
    end
end
idx

% write filenames
newfilenames = filenames(idx);
fid = fopen(outstr,'wt');
for i = 1:length(newfilenames)
    fprintf(fid,'%s\n',newfilenames{i});
end
fclose(fid);
end

function L = list_files(folder)
    L = dir(folder);
    L = L(3:end);
    L = struct2cell(L);
    L = L(1,:);
end

