% this script is to estimate the asymmetric label noise in synthetic data
clear;clc;
nbclass = 10;
Q = rand(nbclass);
for i = 1:nbclass
    Q(i,:) = Q(i,:)/sum(Q(i,:));
    for j = 1:nbclass
        if Q(i,j) > Q(i,i)
            tmp = Q(i,j);
            Q(i,j) = Q(i,i);
            Q(i,i) = tmp;
        end
    end
end
Q
% Q = [1 0 0 0 0 0 0 0 0 0;
%      0 1 0 0 0 0 0 0 0 0;
%      0 0 0.3 0 0 0 0 0.7 0 0;
%      0 0 0 0.3 0 0 0 0 0.7 0;
%      0 0 0 0 1 0 0 0 0 0;
%      0 0 0 0 0 0.3 0.7 0 0 0;
%      0 0 0 0 0 0.7 0.3 0 0 0;
%      0 0.7 0 0 0 0 0 0.3 0 0;
%      0 0 0 0 0 0 0 0 1 0;
%      0 0 0 0 0 0 0 0 0 1];
for loop = 1
    % load data
    images = loadMNISTImages('train-images.idx3-ubyte');
    labels = loadMNISTLabels('train-labels.idx1-ubyte');
    images = double(images');
    labels = labels + 1;

    timages = loadMNISTImages('t10k-images.idx3-ubyte');
    tlabels = loadMNISTLabels('t10k-labels.idx1-ubyte');
    timages = double(timages');
    tlabels = tlabels + 1;

    save('original_mnist.mat','images','labels','timages','tlabels');

    ncleansample = round(0.05*length(labels));
    nsamples = length(labels)-ncleansample;
    tmp = randperm(length(labels));
    XC = images(tmp(1:ncleansample),:);
    YC = labels(tmp(1:ncleansample));
    
    XS = images(tmp(1+ncleansample:end),:);
    YS = labels(tmp(1+ncleansample:end));
    % random flips
    YSt = YS;
    for i = 1:nsamples
        prob = Q(YS(i),:);
        sumprob = cumsum(prob);
        idx = min(find(sumprob>rand));
        YS(i) = idx;
    end
    save('asym_labelnoise_mnist.mat','XC','YC','XS','YS','YSt','Q','timages','tlabels');
end
