import numpy as np
import estimate_pi as espi
import scipy
import scipy.io as sio

# part one: load data
filepath = '../data/mnist/asym_labelnoise_mnist.mat'
data = sio.loadmat(filepath)
print(data)
mat = espi.estimate_pi(data,isPCA=False)
 
