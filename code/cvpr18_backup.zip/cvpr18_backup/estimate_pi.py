import numpy as np
from cvxopt import matrix, solvers
from sklearn.decomposition import PCA
import scipy.spatial.distance as ssd

def rbf_dot(X,Y,gamma=10.0):
    size1 = len(X)
    size2 = len(Y)
    G = X*X
    G = G.sum(1)
    H = Y*Y
    H = H.sum(1)
    G = np.tile(G,(size2,1)).transpose()
    H = np.tile(H,(size1,1))
    C = np.dot(X,Y.transpose())
    K = G + H - 2*C
    K = np.exp(-K/(2*gamma*gamma))
    return K

def estimate_pi(data_dict, isPCA=True):
    yc = data_dict['YC']-1 # labels for clean data
    ys = data_dict['YS']-1 # labels for noisy data
    yt = data_dict['YSt']-1 # ground-truth labels for noisy data
    nclean = len(yc)
    nnoise = len(ys)
    nbclass = len(np.unique(yc))
    PYC = np.zeros((nbclass,1))
    PYS = np.zeros((nbclass,1))
    R = np.zeros((nclean, nbclass))
    for i in np.arange(nbclass):
        # clean data
        inds = [j for j in range(nclean) if yc[j]==i]
        # print(inds)
        R[inds,i] = (1.0/len(inds))

        inds = [j for j in range(nnoise) if yt[j]==i]
        PYC[i] = len(inds)/(nnoise*1.0)

        # noise data
        inds = [j for j in range(nnoise) if ys[j]==i]
        PYS[i] = len(inds)/(nnoise*1.0)

    print("=> finishing computing class probabilities...")
    if isPCA:
        no_dims = 200
        XC = data_dict['XC']
        XS = data_dict['XS']
        X = np.concatenate((XC,XS), axis=0)

        pca = PCA(n_components=no_dims)
        pca.fit(X)
        xc_feat = pca.transform(XC)
        xs_feat = pca.transform(XS)
    else:
        xc_feat = data_dict['XC']
        xs_feat = data_dict['XS']

    print("=> finishing feature extraction...")
    mat_pi = np.zeros((nbclass,nbclass))
    Qest = np.zeros((nbclass, nbclass))
    sigma = np.mean(ssd.pdist(xs_feat))
    for i in np.arange(nbclass):
        kcc = rbf_dot(xc_feat,xc_feat,sigma)
        kcc = (kcc + kcc.transpose())/2.0

        inds = [j for j in range(nnoise) if ys[j]==i]
        ksc = rbf_dot(xs_feat[inds],xc_feat,sigma)

        nYS = len(inds)
        RH = np.dot(R.transpose(), kcc)
        RH = np.dot(RH, R)
        M = np.dot(np.ones((1,nYS)),ksc)
        M = -np.dot(M,R)/(1.0*nYS)
        M = M.transpose()
        RH = matrix(RH)
        M = matrix(M)
        G = -np.eye(nbclass)
        G = matrix(G)
        h = np.zeros((nbclass,1))
        h = matrix(h)
        A = np.ones((1,nbclass))
        A = matrix(A)
        b = matrix(1.0)
        sol = solvers.qp(RH, M, G, h, A, b)
        alpha = np.array(sol['x'])
        beta = alpha*PYS[i]/PYC
        Qest[i,:] = beta.transpose()
        mat_pi[i,:] = alpha.transpose()

    print(mat_pi)
    return mat_pi, sigma, Qest.transpose() 
